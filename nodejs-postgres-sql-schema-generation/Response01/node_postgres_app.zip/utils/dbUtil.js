
const { Sequelize } = require('sequelize');

const dbConnection = new Sequelize('postgres', 'postgres', 'password', {
    host: 'localhost',
    dialect: 'postgres',
});

module.exports = { dbConnection };
