
const { dbConnection } = require('./utils/dbUtil');
const { User, Post } = require('./models');

// Function to initialize the database schema
async function init() {
    try {
        await dbConnection.authenticate();
        console.log('Connection has been established successfully.');

        // Sync all models (create tables)
        await User.sync();
        await Post.sync();
        
        console.log('Schema created successfully.');
    } catch (error) {
        console.error('Unable to connect to the database:', error);
    }
}

init();
