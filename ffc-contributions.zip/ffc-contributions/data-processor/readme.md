```
Create a Draw.io.xml file based on Following Inputs.
Following are the services of the System. Core API, Azure Service Buss, Data Processor, MSSQL Server.
The core API Send Messages to  Azure Service Bus, Azure Service Business Send Messages to Data Processor.
At Data Processor, Messages are filtered by following strings viz., "flightUpdated", "newMessage",  "presenceUpdated" each filter data is written to separate table in MSSQL Server.
Showcase the Diagram inline and also share the file to download locally and reuse it.
```
