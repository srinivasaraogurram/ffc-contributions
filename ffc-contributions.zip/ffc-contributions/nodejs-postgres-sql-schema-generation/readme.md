App is working at below repo
https://github.com/srinivasaraogurram/ffc-contributions/blob/main/nodejs-postgres-sql-schema-generation/Response01/node_postgres_app/README.md
